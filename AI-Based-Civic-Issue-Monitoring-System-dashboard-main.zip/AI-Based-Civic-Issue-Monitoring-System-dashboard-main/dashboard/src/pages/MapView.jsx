import React from 'react';
import MapView from '../components/admin/MapView';

const MapViewPage = () => {
  return <MapView />;
};

export default MapViewPage;
