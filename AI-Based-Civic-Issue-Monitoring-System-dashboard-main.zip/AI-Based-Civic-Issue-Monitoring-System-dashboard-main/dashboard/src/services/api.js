import axios from 'axios';

// Create axios instance with defaults
const api = axios.create({
  baseURL: 'http://localhost:3001/api',
  timeout: 10000,
});

// Mock implementation for development
export const issueService = {
  getIssues: async (filters = {}) => {
    try {
      // Simulate API call with mock data
      const response = await new Promise(resolve => {
        setTimeout(() => {
          resolve({ data: { issues: [] } });
        }, 500);
      });
      return response.data;
    } catch (error) {
      throw error;
    }
  },

  getIssueById: async (id) => {
    try {
      const response = await api.get(`/issues/${id}`);
      return response.data;
    } catch (error) {
      throw error;
    }
  },

  updateIssue: async (id, data) => {
    try {
      const response = await api.put(`/issues/${id}`, data);
      return response.data;
    } catch (error) {
      throw error;
    }
  },

  addComment: async (issueId, comment) => {
    try {
      const response = await api.post(`/issues/${issueId}/comments`, comment);
      return response.data;
    } catch (error) {
      throw error;
    }
  },

  uploadImage: async (issueId, image) => {
    try {
      const formData = new FormData();
      formData.append('image', image);
      const response = await api.post(`/issues/${issueId}/upload`, formData);
      return response.data;
    } catch (error) {
      throw error;
    }
  },
};

export const userService = {
  getUsers: async () => {
    try {
      const response = await api.get('/users');
      return response.data;
    } catch (error) {
      throw error;
    }
  },

  createUser: async (userData) => {
    try {
      const response = await api.post('/users', userData);
      return response.data;
    } catch (error) {
      throw error;
    }
  },

  updateUser: async (id, userData) => {
    try {
      const response = await api.put(`/users/${id}`, userData);
      return response.data;
    } catch (error) {
      throw error;
    }
  },

  deleteUser: async (id) => {
    try {
      const response = await api.delete(`/users/${id}`);
      return response.data;
    } catch (error) {
      throw error;
    }
  },
};

export const analyticsService = {
  getDashboardMetrics: async () => {
    try {
      const response = await api.get('/analytics/dashboard');
      return response.data;
    } catch (error) {
      throw error;
    }
  },

  getIssueAnalytics: async (filters = {}) => {
    try {
      const response = await api.get('/analytics/issues', { params: filters });
      return response.data;
    } catch (error) {
      throw error;
    }
  },

  exportReport: async (format = 'csv') => {
    try {
      const response = await api.get(`/analytics/export/${format}`, {
        responseType: format === 'pdf' ? 'blob' : 'text',
      });
      return response.data;
    } catch (error) {
      throw error;
    }
  },
};

export default api;
